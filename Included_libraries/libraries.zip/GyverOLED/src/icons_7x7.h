#ifndef ICONS_7X7_H
#define ICONS_7X7_H

/**
* Icons 7x7
*
* Между иконками будет отступ
* если использовать setCursor
*
* На Arduino не достаточно памяти для подключения (даже на Mega)
* поэтому копируем те иконки которые нужно (смотрите скетч drawIcons)
*/

const static uint8_t icons_7x7[][] PROGMEM = {};


#endif //ICONS_7X7_H
